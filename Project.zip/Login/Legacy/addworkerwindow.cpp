#include "addworkerwindow.h"
#include "ui_addworkerwindow.h"
#include "mainwindow.h"


AddWorkerWindow::AddWorkerWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AddWorkerWindow){
        ui -> setupUi(this);

}


AddWorkerWindow::~AddWorkerWindow(){
    delete ui;
}


void AddWorkerWindow::on_btnConfirm_clicked(){

}


void AddWorkerWindow::on_btnBack_clicked(){
    MainWindow main;
    main.show();

    this -> close();
}

