#ifndef ADDWORKERWINDOW_H
#define ADDWORKERWINDOW_H

#include <QMainWindow>

namespace Ui {
class AddWorkerWindow;
}

class AddWorkerWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit AddWorkerWindow(QWidget *parent = nullptr);
    ~AddWorkerWindow();

private slots:
    void on_btnConfirm_clicked();

    void on_btnBack_clicked();

private:
    Ui::AddWorkerWindow *ui;
};

#endif // ADDWORKERWINDOW_H
