#include "adminwindow.h"
#include "ui_adminwindow.h"
#include "mainwindow.h"
#include <fstream>
#include <string>
#include <vector>

extern std::vector<std::string> fileArray;
extern std::vector<std::string> formatedFileArray;

AdminWindow::AdminWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::AdminWindow){
        ui -> setupUi(this);

        // Adding items to list
        ui -> lstUsers -> addItem("TEST 1");
        ui -> lstUsers -> addItem("TEST 2");

        std::string tmp;

        for(std::string str : formatedFileArray){
            tmp = str;

            for(size_t i = 0; i < tmp.size(); ++ i){
                if(tmp[i] ==  ';')
                    tmp.replace(i, 1, 1, '\t');
            }
            ui -> lstUsers -> addItem(QString::fromUtf8(tmp.c_str()));
        }
}


AdminWindow::~AdminWindow(){
    delete ui;
}


void AdminWindow::on_btnAdd_clicked(){

}


void AdminWindow::on_btnChange_clicked(){

}


void AdminWindow::on_btnDelete_clicked(){

}


void AdminWindow::on_btnBack_clicked(){
    MainWindow main;
    main.show();

    this -> close();
}


void AdminWindow::on_lstUsers_itemSelectionChanged(){
    ui -> edtUser -> setText(ui -> lstUsers -> currentItem() -> text());
}

