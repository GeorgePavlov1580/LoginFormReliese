#include "workerwindow.h"
#include "ui_workerwindow.h"
#include "mainwindow.h"


WorkerWindow::WorkerWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::WorkerWindow){
        ui -> setupUi(this);

}


WorkerWindow::~WorkerWindow(){
    delete ui;
}


void WorkerWindow::on_btnBack_clicked(){
    MainWindow main;
    main.show();

    this -> close();
}

