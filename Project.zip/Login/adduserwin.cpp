#include "adduserwin.h"
#include "ui_adduserwin.h"

QString addID, addLastN, addFirstN, addLogin, addPass, addRole;

AddUserWin::AddUserWin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddUserWin){
        ui -> setupUi(this);
}


AddUserWin::~AddUserWin(){
    delete ui;
}


void AddUserWin::on_btnConfirm_clicked(){
    addID = ui -> entr1 -> text();
    addLastN = ui -> entr2 -> text();
    addFirstN = ui -> entr3 -> text();
    addLogin = ui -> entr4 -> text();
    addPass = ui -> entr5 -> text();
    addRole = (ui -> rbtnAdmin -> isChecked()) ? QString("admin") : QString("user");
}


void AddUserWin::on_btnBack_clicked(){
    this -> close();
}

