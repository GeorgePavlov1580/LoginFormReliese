#ifndef ADDUSERWIN_H
#define ADDUSERWIN_H

#include <QDialog>

namespace Ui {
class AddUserWin;
}

class AddUserWin : public QDialog
{
    Q_OBJECT

public:
    explicit AddUserWin(QWidget *parent = nullptr);
    ~AddUserWin();

private slots:
    void on_btnConfirm_clicked();

    void on_btnBack_clicked();

private:
    Ui::AddUserWin *ui;
};

#endif // ADDUSERWIN_H
