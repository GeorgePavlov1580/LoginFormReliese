#include "adminwin.h"
#include "ui_adminwin.h"
#include "adduserwin.h"
#include "mainwindow.h"
#include "QMessageBox"

#include <fstream>

extern std::vector<std::string> fileArray;
extern std::string userName;
extern QString addID, addLastN, addFirstN, addLogin, addPass, addRole;

AdminWin::AdminWin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminWin){
        ui -> setupUi(this);

        for(std::string str : fileArray){
            for(size_t i = 0; i < str.size(); ++ i){
                if(str[i] == ';')
                    str.replace(i, 1, 1, '\t');
            }
            ui -> lstUsers -> addItem(QString::fromUtf8(str.c_str()));
        }

        // ui-> lstUsers -> addItem();
         ui -> lblWelcome -> setText(QString("Hello, %1!").arg(QString::fromStdString(userName)));
         this -> setWindowTitle(QString("Admin session - %1").arg(QString::fromStdString(userName)));

}

AdminWin::~AdminWin(){
    // saveDataToFile();
    delete ui;
}


void AdminWin::saveDataToFile(){
    QString tmpQS;
    std::string outputStr(""), tmpStr;
    std::ofstream file("data.csv");

    file << "Id;Last_name;Name;Login;Password;Role;\n";
    fileArray.clear();

    for(size_t i = 0; i < size_t(ui -> lstUsers -> count()); ++ i){
        tmpQS = ui -> lstUsers -> item(i) -> text();
        qDebug() << tmpQS;
        tmpStr = tmpQS.toStdString();

        for(size_t i = 0; i < tmpStr.size(); ++ i)
            if(tmpStr[i] == '\t'){
                tmpStr.replace(i, 1, 1, ';');

        }
        qDebug() << QString::fromStdString(tmpStr);
        fileArray.push_back(tmpStr + '\n');
        file << tmpStr + '\n';
    }

    file.close();
}


void AdminWin::on_lstUsers_itemSelectionChanged(){
    QString tmpQS;
    size_t index(0);

    tmpQS = ui -> lstUsers -> currentItem() -> text();
    while((tmpQS.front() == QChar('\t')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
    index = tmpQS.indexOf(QChar('\t'));
    ui -> entrChID -> setText(tmpQS.mid(0, index));

    tmpQS.remove(0, index);
    while((tmpQS.front() == QChar('\t')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
    index = tmpQS.indexOf(QChar('\t'));
    ui -> entrChLastN -> setText(tmpQS.mid(0, index));

    tmpQS.remove(0, index);
    while((tmpQS.front() == QChar('\t')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
    index = tmpQS.indexOf(QChar('\t'));
    ui -> entrChFirstN -> setText(tmpQS.mid(0, index));

    tmpQS.remove(0, index);
    while((tmpQS.front() == QChar('\t')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
    index = tmpQS.indexOf(QChar('\t'));
    ui -> entrChLog-> setText(tmpQS.mid(0, index));

    tmpQS.remove(0, index);
    while((tmpQS.front() == QChar('\t')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
    index = tmpQS.indexOf(QChar('\t'));
    ui -> entrChPass-> setText(tmpQS.mid(0, index));

    tmpQS.remove(0, index);
    while((tmpQS.front() == QChar('\t')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
    index = tmpQS.indexOf(QChar('\t'));
    ui -> entrChRole-> setText(tmpQS.mid(0, index));
}


void AdminWin::on_btnBack_clicked(){
    QMessageBox::StandardButton res = QMessageBox::question(this,
                                                            " Save and continue?",
                                                            "Do you want to save changes\nyou've made in file?",
                                                            QMessageBox::Yes | QMessageBox::No | QMessageBox::Abort);

    if(res == QMessageBox::Yes){
        saveDataToFile();
        this -> close();
    }else if(res == QMessageBox::No){
        this -> close();
    }
    else
        return;
}


void AdminWin::on_btnDelUsr_clicked(){
   size_t countRows = ui -> lstUsers -> count();
    qDebug() << QString::number(countRows);
    if(countRows == 1)
        return;
    else
        delete ui -> lstUsers -> currentItem();
}


void AdminWin::on_btnAddUsr_clicked(){
    AddUserWin addUserW;

    addUserW.setModal(true);
    addUserW.exec();

    ui -> lstUsers -> addItem(addID + '\t' + addLastN + '\t' + addFirstN + '\t' + addLogin + '\t' + addPass + '\t' + addRole);
}


void AdminWin::on_btnChangeUsr_clicked(){
    QString chID, chLastN, chFirstN, chLogin, chPass, chRole;

    chID = ui -> entrChID -> text();
    chLastN = ui -> entrChLastN -> text();
    chFirstN = ui -> entrChFirstN -> text();
    chLogin = ui -> entrChLog -> text();
    chPass = ui -> entrChPass -> text();
    chRole = ui -> entrChRole -> text();

    ui -> lstUsers -> item(ui -> lstUsers -> currentRow()) -> setText(chID + '\t' +  chLastN + '\t' + chFirstN + '\t' + chLogin + '\t' + chPass + '\t' + chRole + '\t');
}

