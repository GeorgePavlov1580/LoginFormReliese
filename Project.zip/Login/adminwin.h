#ifndef ADMINWIN_H
#define ADMINWIN_H

#include <QDialog>

namespace Ui {
class AdminWin;
}

class AdminWin : public QDialog
{
    Q_OBJECT

public:
    explicit AdminWin(QWidget *parent = nullptr);
    ~AdminWin();

private slots:
    void on_lstUsers_itemSelectionChanged();
    void saveDataToFile();
    void on_btnBack_clicked();

    void on_btnDelUsr_clicked();

    void on_btnAddUsr_clicked();

    void on_btnChangeUsr_clicked();

private:
    Ui::AdminWin *ui;
};

#endif // ADMINWIN_H
