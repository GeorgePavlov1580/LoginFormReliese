#include "mainwindow.h"
#include "adminwin.h"
#include "userwin.h"

#include <QApplication>
#include <fstream>
#include <string>
#include <vector>

size_t N;
std::vector<std::string> fileArray;
std::vector<std::string> formatedFileArray;


int main(int argc, char *argv[]){
    QApplication a(argc, argv);

    // Reading from .csv file
    std::string tmpS;
    std::ifstream input_file("data.csv");

    while(getline(input_file, tmpS)){
        ++ N;
        fileArray.push_back(tmpS);
        formatedFileArray.push_back(tmpS);
    }

    fileArray.erase(fileArray.begin());

    input_file.close();
    tmpS = "";

    for(std::string str : formatedFileArray){
        for(size_t i = 0; i < str.size(); ++ i){
            if(str[i] == '\t')
                str.replace(i, 1, 1, '\t');
        }
    }

//  Windows
//    == Legacy ==
//    WorkerWindow worker;
//    AddWorkerWindow addWorker;
//    AdminWindow admin;

//    == Legacy ==
//    worker.show();
//    addWorker.show();

    MainWindow mainWin;
//    AdminWin admWin;
//    UserWin usrWin;

    mainWin.show();
//    admWin.show();
//    usrWin.show();

    return a.exec();
}
