#include "mainwindow.h"
#include "QMessageBox"
#include "ui_mainwindow.h"
#include "QDebug"
#include <string>
#include <fstream>
#include <vector>

extern std::vector<std::string> fileArray;
extern std::vector<std::string> formatedFileArray;

std::string userLogin, userPassword, userName;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow){
        ui -> setupUi(this);

}

MainWindow::~MainWindow(){
    delete ui;
}

std::string getUserName(std::string login, std::string password){
    std::string tmpStr;
    size_t countSign(0), count(0), index(0);


    for(std::string str : fileArray)
        if((str.find(login) != std::string::npos) && (str.find(password) != std::string::npos))
            tmpStr = str;

    // qDebug() << QString::fromStdString(tmpStr);

    while(countSign != 2){
        if(tmpStr[count] == ';') ++ countSign;
        ++ count;
        ++ index;
    }

    tmpStr.erase(0, index);

    tmpStr = tmpStr.substr(0, tmpStr.find(';'));

    // qDebug() << QString::fromStdString(tmpStr);
    // tmpStr.erase(tmpStr.find(';'), tmpStr.end() - tmpStr.find(';'));

    return tmpStr;
}


bool checkRole(std::string login, std::string password){ // true - admin; false - user
    std::string tmpStr, roleStr;

    for(std::string str : fileArray)
        if((str.find(login) != std::string::npos) && (str.find(password) != std::string::npos))
            tmpStr = str;

    tmpStr.pop_back();

    roleStr = tmpStr.substr(tmpStr.rfind(';'), tmpStr.size() - 1);
    roleStr.erase(0, 1);
    qDebug() << QString::fromStdString(roleStr);

    return (roleStr == "admin") ? true : false;
}

bool checkUser(std::string login, std::string password){
    for(std::string str : fileArray)
        if((str.find(login) != std::string::npos) && (str.find(password) != std::string::npos))
            return true;

     return false;
}

void MainWindow::on_btnConfirm_clicked(){
    userLogin    = (ui -> entr1 ->text()).toStdString();
    userPassword = (ui -> entr2 ->text()).toStdString();

    if(checkUser(userLogin, userPassword)){
        QMessageBox::information(this, " Welcome!", "Press OK to continue...");

        userName = getUserName(userLogin, userPassword);
        qDebug() << QString::fromStdString(userName);
        if(checkRole(userLogin, userPassword)){
            AdminWin adminW;
            adminW.exec();
        }else{
            UserWin userW;
            userW.exec();
        }
    }else{
        QMessageBox::warning(this, " User not found!", "User not found, try again!");
    }
}

