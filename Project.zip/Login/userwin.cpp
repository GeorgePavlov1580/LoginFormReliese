#include "userwin.h"
#include "ui_userwin.h"

extern std::string userName, userLogin, userPassword;
extern std::vector<std::string> fileArray;

std::string findStr(std::string login, std::string password);

UserWin::UserWin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserWin){
        ui -> setupUi(this);
        ui -> lblWelcome -> setText(QString("Hello, %1!").arg(QString::fromStdString(userName)));
        this -> setWindowTitle(QString("User session - %1").arg(QString::fromStdString(userName)));


        QString tmpQS(QString::fromStdString(findStr(userLogin, userPassword)));
        size_t index(0);

        while((tmpQS.front() == QChar(';')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
        index = tmpQS.indexOf(QChar(';'));
        ui -> entrChID -> setText(tmpQS.mid(0, index));

        tmpQS.remove(0, index);
        while((tmpQS.front() == QChar(';')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
        index = tmpQS.indexOf(QChar(';'));
        ui -> entrChLastN -> setText(tmpQS.mid(0, index));

        tmpQS.remove(0, index);
        while((tmpQS.front() == QChar(';')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
        index = tmpQS.indexOf(QChar(';'));
        ui -> entrChFirstN -> setText(tmpQS.mid(0, index));

        tmpQS.remove(0, index);
        while((tmpQS.front() == QChar(';')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
        index = tmpQS.indexOf(QChar(';'));
        ui -> entrChLog-> setText(tmpQS.mid(0, index));

        tmpQS.remove(0, index);
        while((tmpQS.front() == QChar(';')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
        index = tmpQS.indexOf(QChar(';'));
        ui -> entrChPass-> setText(tmpQS.mid(0, index));

        tmpQS.remove(0, index);
        while((tmpQS.front() == QChar(';')) || (tmpQS.front() == QChar(' '))) tmpQS.remove(0, 1);
        index = tmpQS.indexOf(QChar(';'));
        ui -> entrChRole-> setText(tmpQS.mid(0, index));
}


std::string findStr(std::string login, std::string password){
    std::string userStr;
    for(std::string str : fileArray){
        if((str.find(login) != std::string::npos) && (str.find(password) != std::string::npos)){
            userStr = str;
            break;
        }
    }

    return userStr;
}


UserWin::~UserWin(){
    delete ui;
}

void UserWin::on_btnBack_clicked(){ this -> close(); }

