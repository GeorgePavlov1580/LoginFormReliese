#ifndef USERWIN_H
#define USERWIN_H

#include <QDialog>

namespace Ui {
class UserWin;
}

class UserWin : public QDialog
{
    Q_OBJECT

public:
    explicit UserWin(QWidget *parent = nullptr);
    ~UserWin();

private slots:
    void on_btnBack_clicked();

private:
    Ui::UserWin *ui;
};

#endif // USERWIN_H
