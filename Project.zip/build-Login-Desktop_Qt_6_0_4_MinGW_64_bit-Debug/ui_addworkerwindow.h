/********************************************************************************
** Form generated from reading UI file 'addworkerwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.0.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDWORKERWINDOW_H
#define UI_ADDWORKERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddWorkerWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_5;
    QVBoxLayout *main;
    QHBoxLayout *login;
    QLabel *lblLog;
    QLineEdit *entr1;
    QHBoxLayout *password;
    QLabel *lblPass;
    QLineEdit *entr2;
    QHBoxLayout *first_name;
    QLabel *lblFirst;
    QLineEdit *entr3;
    QHBoxLayout *last_name;
    QLabel *lblLast;
    QLineEdit *entr4;
    QLabel *LblRole;
    QRadioButton *radUser;
    QRadioButton *radAdmin;
    QPushButton *btnConfirm;
    QPushButton *btnBack;

    void setupUi(QMainWindow *AddWorkerWindow)
    {
        if (AddWorkerWindow->objectName().isEmpty())
            AddWorkerWindow->setObjectName(QString::fromUtf8("AddWorkerWindow"));
        AddWorkerWindow->resize(400, 265);
        AddWorkerWindow->setMinimumSize(QSize(400, 265));
        AddWorkerWindow->setMaximumSize(QSize(1000, 1000));
        AddWorkerWindow->setStyleSheet(QString::fromUtf8("font: 11pt \"Consolas\";\n"
"background-color: rgb(170, 255, 0);"));
        centralwidget = new QWidget(AddWorkerWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout_5 = new QHBoxLayout(centralwidget);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        main = new QVBoxLayout();
        main->setObjectName(QString::fromUtf8("main"));
        login = new QHBoxLayout();
        login->setObjectName(QString::fromUtf8("login"));
        lblLog = new QLabel(centralwidget);
        lblLog->setObjectName(QString::fromUtf8("lblLog"));

        login->addWidget(lblLog);

        entr1 = new QLineEdit(centralwidget);
        entr1->setObjectName(QString::fromUtf8("entr1"));
        entr1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        login->addWidget(entr1);


        main->addLayout(login);

        password = new QHBoxLayout();
        password->setObjectName(QString::fromUtf8("password"));
        lblPass = new QLabel(centralwidget);
        lblPass->setObjectName(QString::fromUtf8("lblPass"));

        password->addWidget(lblPass);

        entr2 = new QLineEdit(centralwidget);
        entr2->setObjectName(QString::fromUtf8("entr2"));
        entr2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        password->addWidget(entr2);


        main->addLayout(password);

        first_name = new QHBoxLayout();
        first_name->setObjectName(QString::fromUtf8("first_name"));
        lblFirst = new QLabel(centralwidget);
        lblFirst->setObjectName(QString::fromUtf8("lblFirst"));

        first_name->addWidget(lblFirst);

        entr3 = new QLineEdit(centralwidget);
        entr3->setObjectName(QString::fromUtf8("entr3"));
        entr3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        first_name->addWidget(entr3);


        main->addLayout(first_name);

        last_name = new QHBoxLayout();
        last_name->setObjectName(QString::fromUtf8("last_name"));
        lblLast = new QLabel(centralwidget);
        lblLast->setObjectName(QString::fromUtf8("lblLast"));

        last_name->addWidget(lblLast);

        entr4 = new QLineEdit(centralwidget);
        entr4->setObjectName(QString::fromUtf8("entr4"));
        entr4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        last_name->addWidget(entr4);


        main->addLayout(last_name);

        LblRole = new QLabel(centralwidget);
        LblRole->setObjectName(QString::fromUtf8("LblRole"));

        main->addWidget(LblRole);

        radUser = new QRadioButton(centralwidget);
        radUser->setObjectName(QString::fromUtf8("radUser"));
        radUser->setStyleSheet(QString::fromUtf8(""));

        main->addWidget(radUser);

        radAdmin = new QRadioButton(centralwidget);
        radAdmin->setObjectName(QString::fromUtf8("radAdmin"));

        main->addWidget(radAdmin);

        btnConfirm = new QPushButton(centralwidget);
        btnConfirm->setObjectName(QString::fromUtf8("btnConfirm"));
        btnConfirm->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        main->addWidget(btnConfirm);

        btnBack = new QPushButton(centralwidget);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        main->addWidget(btnBack);


        horizontalLayout_5->addLayout(main);

        AddWorkerWindow->setCentralWidget(centralwidget);

        retranslateUi(AddWorkerWindow);

        QMetaObject::connectSlotsByName(AddWorkerWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AddWorkerWindow)
    {
        AddWorkerWindow->setWindowTitle(QCoreApplication::translate("AddWorkerWindow", " Add user", nullptr));
        lblLog->setText(QCoreApplication::translate("AddWorkerWindow", "Login:     ", nullptr));
        lblPass->setText(QCoreApplication::translate("AddWorkerWindow", "Password:  ", nullptr));
        lblFirst->setText(QCoreApplication::translate("AddWorkerWindow", "First name:", nullptr));
        lblLast->setText(QCoreApplication::translate("AddWorkerWindow", "Last name: ", nullptr));
        LblRole->setText(QCoreApplication::translate("AddWorkerWindow", "Role:", nullptr));
        radUser->setText(QCoreApplication::translate("AddWorkerWindow", "User", nullptr));
        radAdmin->setText(QCoreApplication::translate("AddWorkerWindow", "Admin", nullptr));
        btnConfirm->setText(QCoreApplication::translate("AddWorkerWindow", "Confirm", nullptr));
        btnBack->setText(QCoreApplication::translate("AddWorkerWindow", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddWorkerWindow: public Ui_AddWorkerWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDWORKERWINDOW_H
