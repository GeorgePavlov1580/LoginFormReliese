/********************************************************************************
** Form generated from reading UI file 'adminwin.ui'
**
** Created by: Qt User Interface Compiler version 6.0.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINWIN_H
#define UI_ADMINWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AdminWin
{
public:
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *Main;
    QLabel *lblWelcome;
    QFrame *line;
    QVBoxLayout *UsersList;
    QHBoxLayout *ListLabels;
    QLabel *lblID;
    QLabel *lblLastN;
    QLabel *lblFirstN;
    QLabel *lblLogin;
    QLabel *lblPass;
    QLabel *lblRole;
    QListWidget *lstUsers;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *ChangeUserDataButtons;
    QVBoxLayout *FirstRow;
    QHBoxLayout *ID;
    QLabel *lblChID;
    QLineEdit *entrChID;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *LastName;
    QLabel *lblChLastN;
    QLineEdit *entrChLastN;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *FirstName;
    QLabel *lblChFirstN;
    QLineEdit *entrChFirstN;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *SecondRow;
    QHBoxLayout *Login;
    QLabel *lblChLog;
    QLineEdit *entrChLog;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *Password;
    QLabel *lblChPass;
    QLineEdit *entrChPass;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *Role;
    QLabel *lblChRole;
    QLineEdit *entrChRole;
    QSpacerItem *verticalSpacer_6;
    QHBoxLayout *ActionButtons;
    QPushButton *btnAddUsr;
    QPushButton *btnDelUsr;
    QPushButton *btnChangeUsr;
    QPushButton *btnBack;

    void setupUi(QDialog *AdminWin)
    {
        if (AdminWin->objectName().isEmpty())
            AdminWin->setObjectName(QString::fromUtf8("AdminWin"));
        AdminWin->resize(790, 581);
        AdminWin->setMinimumSize(QSize(470, 520));
        AdminWin->setMaximumSize(QSize(1200, 750));
        AdminWin->setStyleSheet(QString::fromUtf8("font: 11pt \"Consolas\";\n"
"background-color: rgb(170, 255, 0);"));
        verticalLayout_5 = new QVBoxLayout(AdminWin);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        Main = new QVBoxLayout();
        Main->setObjectName(QString::fromUtf8("Main"));
        lblWelcome = new QLabel(AdminWin);
        lblWelcome->setObjectName(QString::fromUtf8("lblWelcome"));
        QFont font;
        font.setPointSize(16);
        font.setBold(false);
        font.setItalic(false);
        lblWelcome->setFont(font);
        lblWelcome->setStyleSheet(QString::fromUtf8("font: 16pt \"Consolas\";"));
        lblWelcome->setScaledContents(true);
        lblWelcome->setAlignment(Qt::AlignCenter);
        lblWelcome->setWordWrap(true);

        Main->addWidget(lblWelcome);

        line = new QFrame(AdminWin);
        line->setObjectName(QString::fromUtf8("line"));
        line->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        Main->addWidget(line);

        UsersList = new QVBoxLayout();
        UsersList->setSpacing(0);
        UsersList->setObjectName(QString::fromUtf8("UsersList"));
        ListLabels = new QHBoxLayout();
        ListLabels->setSpacing(0);
        ListLabels->setObjectName(QString::fromUtf8("ListLabels"));
        lblID = new QLabel(AdminWin);
        lblID->setObjectName(QString::fromUtf8("lblID"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lblID->sizePolicy().hasHeightForWidth());
        lblID->setSizePolicy(sizePolicy);
        lblID->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ListLabels->addWidget(lblID);

        lblLastN = new QLabel(AdminWin);
        lblLastN->setObjectName(QString::fromUtf8("lblLastN"));
        sizePolicy.setHeightForWidth(lblLastN->sizePolicy().hasHeightForWidth());
        lblLastN->setSizePolicy(sizePolicy);
        lblLastN->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ListLabels->addWidget(lblLastN);

        lblFirstN = new QLabel(AdminWin);
        lblFirstN->setObjectName(QString::fromUtf8("lblFirstN"));
        sizePolicy.setHeightForWidth(lblFirstN->sizePolicy().hasHeightForWidth());
        lblFirstN->setSizePolicy(sizePolicy);
        lblFirstN->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ListLabels->addWidget(lblFirstN);

        lblLogin = new QLabel(AdminWin);
        lblLogin->setObjectName(QString::fromUtf8("lblLogin"));
        sizePolicy.setHeightForWidth(lblLogin->sizePolicy().hasHeightForWidth());
        lblLogin->setSizePolicy(sizePolicy);
        lblLogin->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ListLabels->addWidget(lblLogin);

        lblPass = new QLabel(AdminWin);
        lblPass->setObjectName(QString::fromUtf8("lblPass"));
        sizePolicy.setHeightForWidth(lblPass->sizePolicy().hasHeightForWidth());
        lblPass->setSizePolicy(sizePolicy);
        lblPass->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ListLabels->addWidget(lblPass);

        lblRole = new QLabel(AdminWin);
        lblRole->setObjectName(QString::fromUtf8("lblRole"));
        lblRole->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ListLabels->addWidget(lblRole);


        UsersList->addLayout(ListLabels);

        lstUsers = new QListWidget(AdminWin);
        lstUsers->setObjectName(QString::fromUtf8("lstUsers"));
        lstUsers->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        UsersList->addWidget(lstUsers);

        verticalSpacer = new QSpacerItem(20, 9, QSizePolicy::Minimum, QSizePolicy::Fixed);

        UsersList->addItem(verticalSpacer);

        ChangeUserDataButtons = new QHBoxLayout();
        ChangeUserDataButtons->setObjectName(QString::fromUtf8("ChangeUserDataButtons"));
        FirstRow = new QVBoxLayout();
        FirstRow->setObjectName(QString::fromUtf8("FirstRow"));
        ID = new QHBoxLayout();
        ID->setSpacing(0);
        ID->setObjectName(QString::fromUtf8("ID"));
        lblChID = new QLabel(AdminWin);
        lblChID->setObjectName(QString::fromUtf8("lblChID"));
        lblChID->setStyleSheet(QString::fromUtf8(""));

        ID->addWidget(lblChID);

        entrChID = new QLineEdit(AdminWin);
        entrChID->setObjectName(QString::fromUtf8("entrChID"));
        entrChID->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ID->addWidget(entrChID);


        FirstRow->addLayout(ID);

        verticalSpacer_2 = new QSpacerItem(3, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        FirstRow->addItem(verticalSpacer_2);

        LastName = new QHBoxLayout();
        LastName->setSpacing(0);
        LastName->setObjectName(QString::fromUtf8("LastName"));
        lblChLastN = new QLabel(AdminWin);
        lblChLastN->setObjectName(QString::fromUtf8("lblChLastN"));
        lblChLastN->setStyleSheet(QString::fromUtf8(""));

        LastName->addWidget(lblChLastN);

        entrChLastN = new QLineEdit(AdminWin);
        entrChLastN->setObjectName(QString::fromUtf8("entrChLastN"));
        entrChLastN->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        LastName->addWidget(entrChLastN);


        FirstRow->addLayout(LastName);

        verticalSpacer_3 = new QSpacerItem(20, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        FirstRow->addItem(verticalSpacer_3);

        FirstName = new QHBoxLayout();
        FirstName->setSpacing(0);
        FirstName->setObjectName(QString::fromUtf8("FirstName"));
        lblChFirstN = new QLabel(AdminWin);
        lblChFirstN->setObjectName(QString::fromUtf8("lblChFirstN"));
        lblChFirstN->setStyleSheet(QString::fromUtf8(""));

        FirstName->addWidget(lblChFirstN);

        entrChFirstN = new QLineEdit(AdminWin);
        entrChFirstN->setObjectName(QString::fromUtf8("entrChFirstN"));
        entrChFirstN->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        FirstName->addWidget(entrChFirstN);


        FirstRow->addLayout(FirstName);


        ChangeUserDataButtons->addLayout(FirstRow);

        horizontalSpacer = new QSpacerItem(9, 5, QSizePolicy::Fixed, QSizePolicy::Minimum);

        ChangeUserDataButtons->addItem(horizontalSpacer);

        SecondRow = new QVBoxLayout();
        SecondRow->setObjectName(QString::fromUtf8("SecondRow"));
        Login = new QHBoxLayout();
        Login->setSpacing(0);
        Login->setObjectName(QString::fromUtf8("Login"));
        lblChLog = new QLabel(AdminWin);
        lblChLog->setObjectName(QString::fromUtf8("lblChLog"));
        lblChLog->setStyleSheet(QString::fromUtf8(""));

        Login->addWidget(lblChLog);

        entrChLog = new QLineEdit(AdminWin);
        entrChLog->setObjectName(QString::fromUtf8("entrChLog"));
        entrChLog->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        Login->addWidget(entrChLog);


        SecondRow->addLayout(Login);

        verticalSpacer_4 = new QSpacerItem(20, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        SecondRow->addItem(verticalSpacer_4);

        Password = new QHBoxLayout();
        Password->setSpacing(0);
        Password->setObjectName(QString::fromUtf8("Password"));
        lblChPass = new QLabel(AdminWin);
        lblChPass->setObjectName(QString::fromUtf8("lblChPass"));
        lblChPass->setStyleSheet(QString::fromUtf8(""));

        Password->addWidget(lblChPass);

        entrChPass = new QLineEdit(AdminWin);
        entrChPass->setObjectName(QString::fromUtf8("entrChPass"));
        entrChPass->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        Password->addWidget(entrChPass);


        SecondRow->addLayout(Password);

        verticalSpacer_5 = new QSpacerItem(20, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        SecondRow->addItem(verticalSpacer_5);

        Role = new QHBoxLayout();
        Role->setSpacing(0);
        Role->setObjectName(QString::fromUtf8("Role"));
        lblChRole = new QLabel(AdminWin);
        lblChRole->setObjectName(QString::fromUtf8("lblChRole"));
        lblChRole->setStyleSheet(QString::fromUtf8(""));

        Role->addWidget(lblChRole);

        entrChRole = new QLineEdit(AdminWin);
        entrChRole->setObjectName(QString::fromUtf8("entrChRole"));
        entrChRole->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        Role->addWidget(entrChRole);


        SecondRow->addLayout(Role);


        ChangeUserDataButtons->addLayout(SecondRow);


        UsersList->addLayout(ChangeUserDataButtons);


        Main->addLayout(UsersList);

        verticalSpacer_6 = new QSpacerItem(20, 5, QSizePolicy::Minimum, QSizePolicy::Fixed);

        Main->addItem(verticalSpacer_6);

        ActionButtons = new QHBoxLayout();
        ActionButtons->setObjectName(QString::fromUtf8("ActionButtons"));
        btnAddUsr = new QPushButton(AdminWin);
        btnAddUsr->setObjectName(QString::fromUtf8("btnAddUsr"));
        btnAddUsr->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ActionButtons->addWidget(btnAddUsr);

        btnDelUsr = new QPushButton(AdminWin);
        btnDelUsr->setObjectName(QString::fromUtf8("btnDelUsr"));
        btnDelUsr->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ActionButtons->addWidget(btnDelUsr);

        btnChangeUsr = new QPushButton(AdminWin);
        btnChangeUsr->setObjectName(QString::fromUtf8("btnChangeUsr"));
        btnChangeUsr->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        ActionButtons->addWidget(btnChangeUsr);


        Main->addLayout(ActionButtons);

        btnBack = new QPushButton(AdminWin);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        Main->addWidget(btnBack);


        verticalLayout_5->addLayout(Main);


        retranslateUi(AdminWin);

        QMetaObject::connectSlotsByName(AdminWin);
    } // setupUi

    void retranslateUi(QDialog *AdminWin)
    {
        AdminWin->setWindowTitle(QCoreApplication::translate("AdminWin", " Admin session - {Name}", nullptr));
        lblWelcome->setText(QCoreApplication::translate("AdminWin", "Hello, {Name}!", nullptr));
        lblID->setText(QCoreApplication::translate("AdminWin", "ID ", nullptr));
        lblLastN->setText(QCoreApplication::translate("AdminWin", "  Last name ", nullptr));
        lblFirstN->setText(QCoreApplication::translate("AdminWin", "   First name ", nullptr));
        lblLogin->setText(QCoreApplication::translate("AdminWin", " Login ", nullptr));
        lblPass->setText(QCoreApplication::translate("AdminWin", "   Password ", nullptr));
        lblRole->setText(QCoreApplication::translate("AdminWin", "Role ", nullptr));
        lblChID->setText(QCoreApplication::translate("AdminWin", "ID:         ", nullptr));
        lblChLastN->setText(QCoreApplication::translate("AdminWin", "Last name:  ", nullptr));
        lblChFirstN->setText(QCoreApplication::translate("AdminWin", "First name: ", nullptr));
        lblChLog->setText(QCoreApplication::translate("AdminWin", "Login:    ", nullptr));
        lblChPass->setText(QCoreApplication::translate("AdminWin", "Password: ", nullptr));
        lblChRole->setText(QCoreApplication::translate("AdminWin", "Role:     ", nullptr));
        btnAddUsr->setText(QCoreApplication::translate("AdminWin", "Add user", nullptr));
        btnDelUsr->setText(QCoreApplication::translate("AdminWin", "Delete user", nullptr));
        btnChangeUsr->setText(QCoreApplication::translate("AdminWin", "Change user", nullptr));
        btnBack->setText(QCoreApplication::translate("AdminWin", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminWin: public Ui_AdminWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINWIN_H
