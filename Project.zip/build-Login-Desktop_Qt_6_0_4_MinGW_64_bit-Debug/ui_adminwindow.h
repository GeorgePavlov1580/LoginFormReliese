/********************************************************************************
** Form generated from reading UI file 'adminwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.0.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADMINWINDOW_H
#define UI_ADMINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AdminWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *main;
    QHBoxLayout *list_labels;
    QLabel *lblID;
    QLabel *lblLogin;
    QLabel *lblPass;
    QLabel *lblRole;
    QLabel *lblName;
    QListWidget *lstUsers;
    QSpacerItem *verticalSpacer_3;
    QLineEdit *edtUser;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *list_buttons;
    QPushButton *btnAdd;
    QSpacerItem *horizontalSpacer;
    QPushButton *btnChange;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *btnDelete;
    QSpacerItem *verticalSpacer_2;
    QPushButton *btnBack;

    void setupUi(QMainWindow *AdminWindow)
    {
        if (AdminWindow->objectName().isEmpty())
            AdminWindow->setObjectName(QString::fromUtf8("AdminWindow"));
        AdminWindow->resize(640, 480);
        AdminWindow->setMinimumSize(QSize(600, 400));
        AdminWindow->setMaximumSize(QSize(1500, 1500));
        AdminWindow->setStyleSheet(QString::fromUtf8("font: 11pt \"Consolas\";\n"
"background-color: rgb(170, 255, 0);"));
        centralwidget = new QWidget(AdminWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        main = new QVBoxLayout();
        main->setSpacing(0);
        main->setObjectName(QString::fromUtf8("main"));
        list_labels = new QHBoxLayout();
        list_labels->setSpacing(0);
        list_labels->setObjectName(QString::fromUtf8("list_labels"));
        lblID = new QLabel(centralwidget);
        lblID->setObjectName(QString::fromUtf8("lblID"));
        lblID->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-right-color: rgb(0, 0, 0);\n"
"border-top-color: rgb(0, 0, 0);"));

        list_labels->addWidget(lblID);

        lblLogin = new QLabel(centralwidget);
        lblLogin->setObjectName(QString::fromUtf8("lblLogin"));
        lblLogin->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-right-color: rgb(0, 0, 0);\n"
"border-top-color: rgb(0, 0, 0);"));

        list_labels->addWidget(lblLogin);

        lblPass = new QLabel(centralwidget);
        lblPass->setObjectName(QString::fromUtf8("lblPass"));
        lblPass->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-right-color: rgb(0, 0, 0);\n"
"border-top-color: rgb(0, 0, 0);"));

        list_labels->addWidget(lblPass);

        lblRole = new QLabel(centralwidget);
        lblRole->setObjectName(QString::fromUtf8("lblRole"));
        lblRole->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-right-color: rgb(0, 0, 0);\n"
"border-top-color: rgb(0, 0, 0);"));

        list_labels->addWidget(lblRole);

        lblName = new QLabel(centralwidget);
        lblName->setObjectName(QString::fromUtf8("lblName"));
        lblName->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-right-color: rgb(0, 0, 0);\n"
"border-top-color: rgb(0, 0, 0);\n"
"border-left-color: rgb(0, 0, 0);"));

        list_labels->addWidget(lblName);


        main->addLayout(list_labels);

        lstUsers = new QListWidget(centralwidget);
        lstUsers->setObjectName(QString::fromUtf8("lstUsers"));
        lstUsers->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);\n"
"border-color: rgb(0, 0, 0);"));
        lstUsers->setAutoScroll(true);

        main->addWidget(lstUsers);

        verticalSpacer_3 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        main->addItem(verticalSpacer_3);

        edtUser = new QLineEdit(centralwidget);
        edtUser->setObjectName(QString::fromUtf8("edtUser"));
        edtUser->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        main->addWidget(edtUser);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        main->addItem(verticalSpacer);

        list_buttons = new QHBoxLayout();
        list_buttons->setObjectName(QString::fromUtf8("list_buttons"));
        btnAdd = new QPushButton(centralwidget);
        btnAdd->setObjectName(QString::fromUtf8("btnAdd"));
        btnAdd->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        list_buttons->addWidget(btnAdd);

        horizontalSpacer = new QSpacerItem(5, 5, QSizePolicy::Fixed, QSizePolicy::Minimum);

        list_buttons->addItem(horizontalSpacer);

        btnChange = new QPushButton(centralwidget);
        btnChange->setObjectName(QString::fromUtf8("btnChange"));
        btnChange->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        list_buttons->addWidget(btnChange);

        horizontalSpacer_2 = new QSpacerItem(5, 5, QSizePolicy::Fixed, QSizePolicy::Minimum);

        list_buttons->addItem(horizontalSpacer_2);

        btnDelete = new QPushButton(centralwidget);
        btnDelete->setObjectName(QString::fromUtf8("btnDelete"));
        btnDelete->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        list_buttons->addWidget(btnDelete);


        main->addLayout(list_buttons);

        verticalSpacer_2 = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        main->addItem(verticalSpacer_2);

        btnBack = new QPushButton(centralwidget);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        main->addWidget(btnBack);


        verticalLayout->addLayout(main);

        AdminWindow->setCentralWidget(centralwidget);

        retranslateUi(AdminWindow);

        QMetaObject::connectSlotsByName(AdminWindow);
    } // setupUi

    void retranslateUi(QMainWindow *AdminWindow)
    {
        AdminWindow->setWindowTitle(QCoreApplication::translate("AdminWindow", " Admin", nullptr));
        lblID->setText(QCoreApplication::translate("AdminWindow", "ID ", nullptr));
        lblLogin->setText(QCoreApplication::translate("AdminWindow", "Login ", nullptr));
        lblPass->setText(QCoreApplication::translate("AdminWindow", "Password ", nullptr));
        lblRole->setText(QCoreApplication::translate("AdminWindow", "Role ", nullptr));
        lblName->setText(QCoreApplication::translate("AdminWindow", "Name ", nullptr));
        btnAdd->setText(QCoreApplication::translate("AdminWindow", "Add user", nullptr));
        btnChange->setText(QCoreApplication::translate("AdminWindow", "Change user", nullptr));
        btnDelete->setText(QCoreApplication::translate("AdminWindow", "Delete user", nullptr));
        btnBack->setText(QCoreApplication::translate("AdminWindow", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AdminWindow: public Ui_AdminWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADMINWINDOW_H
