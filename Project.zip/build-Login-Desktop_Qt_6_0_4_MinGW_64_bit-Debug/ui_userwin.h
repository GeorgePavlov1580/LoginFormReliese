/********************************************************************************
** Form generated from reading UI file 'userwin.ui'
**
** Created by: Qt User Interface Compiler version 6.0.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERWIN_H
#define UI_USERWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_UserWin
{
public:
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *Main;
    QLabel *lblWelcome;
    QFrame *line;
    QLabel *lblInfo;
    QHBoxLayout *ChangeUserDataButtons;
    QVBoxLayout *FirstRow;
    QHBoxLayout *ID;
    QLabel *lblChID;
    QLineEdit *entrChID;
    QSpacerItem *verticalSpacer_2;
    QHBoxLayout *LastName;
    QLabel *lblChLastN;
    QLineEdit *entrChLastN;
    QSpacerItem *verticalSpacer_3;
    QHBoxLayout *FirstName;
    QLabel *lblChFirstN;
    QLineEdit *entrChFirstN;
    QSpacerItem *horizontalSpacer;
    QVBoxLayout *SecondRow;
    QHBoxLayout *Login;
    QLabel *lblChLog;
    QLineEdit *entrChLog;
    QSpacerItem *verticalSpacer_4;
    QHBoxLayout *Password;
    QLabel *lblChPass;
    QLineEdit *entrChPass;
    QSpacerItem *verticalSpacer_5;
    QHBoxLayout *Role;
    QLabel *lblChRole;
    QLineEdit *entrChRole;
    QSpacerItem *verticalSpacer;
    QPushButton *btnBack;

    void setupUi(QDialog *UserWin)
    {
        if (UserWin->objectName().isEmpty())
            UserWin->setObjectName(QString::fromUtf8("UserWin"));
        UserWin->resize(450, 230);
        UserWin->setMinimumSize(QSize(450, 230));
        UserWin->setMaximumSize(QSize(1000, 250));
        UserWin->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 255, 0);\n"
"font: 11pt \"Consolas\";"));
        verticalLayout_2 = new QVBoxLayout(UserWin);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        Main = new QVBoxLayout();
        Main->setObjectName(QString::fromUtf8("Main"));
        lblWelcome = new QLabel(UserWin);
        lblWelcome->setObjectName(QString::fromUtf8("lblWelcome"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lblWelcome->sizePolicy().hasHeightForWidth());
        lblWelcome->setSizePolicy(sizePolicy);
        lblWelcome->setStyleSheet(QString::fromUtf8("font: 16pt \"Consolas\";"));
        lblWelcome->setAlignment(Qt::AlignCenter);
        lblWelcome->setWordWrap(true);

        Main->addWidget(lblWelcome);

        line = new QFrame(UserWin);
        line->setObjectName(QString::fromUtf8("line"));
        line->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        Main->addWidget(line);

        lblInfo = new QLabel(UserWin);
        lblInfo->setObjectName(QString::fromUtf8("lblInfo"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(lblInfo->sizePolicy().hasHeightForWidth());
        lblInfo->setSizePolicy(sizePolicy1);
        lblInfo->setAlignment(Qt::AlignCenter);
        lblInfo->setWordWrap(true);

        Main->addWidget(lblInfo);

        ChangeUserDataButtons = new QHBoxLayout();
        ChangeUserDataButtons->setObjectName(QString::fromUtf8("ChangeUserDataButtons"));
        FirstRow = new QVBoxLayout();
        FirstRow->setObjectName(QString::fromUtf8("FirstRow"));
        ID = new QHBoxLayout();
        ID->setSpacing(0);
        ID->setObjectName(QString::fromUtf8("ID"));
        lblChID = new QLabel(UserWin);
        lblChID->setObjectName(QString::fromUtf8("lblChID"));
        lblChID->setStyleSheet(QString::fromUtf8(""));

        ID->addWidget(lblChID);

        entrChID = new QLineEdit(UserWin);
        entrChID->setObjectName(QString::fromUtf8("entrChID"));
        entrChID->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        entrChID->setReadOnly(true);

        ID->addWidget(entrChID);


        FirstRow->addLayout(ID);

        verticalSpacer_2 = new QSpacerItem(3, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        FirstRow->addItem(verticalSpacer_2);

        LastName = new QHBoxLayout();
        LastName->setSpacing(0);
        LastName->setObjectName(QString::fromUtf8("LastName"));
        lblChLastN = new QLabel(UserWin);
        lblChLastN->setObjectName(QString::fromUtf8("lblChLastN"));
        lblChLastN->setStyleSheet(QString::fromUtf8(""));

        LastName->addWidget(lblChLastN);

        entrChLastN = new QLineEdit(UserWin);
        entrChLastN->setObjectName(QString::fromUtf8("entrChLastN"));
        entrChLastN->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        entrChLastN->setReadOnly(true);

        LastName->addWidget(entrChLastN);


        FirstRow->addLayout(LastName);

        verticalSpacer_3 = new QSpacerItem(20, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        FirstRow->addItem(verticalSpacer_3);

        FirstName = new QHBoxLayout();
        FirstName->setSpacing(0);
        FirstName->setObjectName(QString::fromUtf8("FirstName"));
        lblChFirstN = new QLabel(UserWin);
        lblChFirstN->setObjectName(QString::fromUtf8("lblChFirstN"));
        lblChFirstN->setStyleSheet(QString::fromUtf8(""));

        FirstName->addWidget(lblChFirstN);

        entrChFirstN = new QLineEdit(UserWin);
        entrChFirstN->setObjectName(QString::fromUtf8("entrChFirstN"));
        entrChFirstN->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        entrChFirstN->setReadOnly(true);

        FirstName->addWidget(entrChFirstN);


        FirstRow->addLayout(FirstName);


        ChangeUserDataButtons->addLayout(FirstRow);

        horizontalSpacer = new QSpacerItem(9, 5, QSizePolicy::Fixed, QSizePolicy::Minimum);

        ChangeUserDataButtons->addItem(horizontalSpacer);

        SecondRow = new QVBoxLayout();
        SecondRow->setObjectName(QString::fromUtf8("SecondRow"));
        Login = new QHBoxLayout();
        Login->setSpacing(0);
        Login->setObjectName(QString::fromUtf8("Login"));
        lblChLog = new QLabel(UserWin);
        lblChLog->setObjectName(QString::fromUtf8("lblChLog"));
        lblChLog->setStyleSheet(QString::fromUtf8(""));

        Login->addWidget(lblChLog);

        entrChLog = new QLineEdit(UserWin);
        entrChLog->setObjectName(QString::fromUtf8("entrChLog"));
        entrChLog->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        entrChLog->setReadOnly(true);

        Login->addWidget(entrChLog);


        SecondRow->addLayout(Login);

        verticalSpacer_4 = new QSpacerItem(20, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        SecondRow->addItem(verticalSpacer_4);

        Password = new QHBoxLayout();
        Password->setSpacing(0);
        Password->setObjectName(QString::fromUtf8("Password"));
        lblChPass = new QLabel(UserWin);
        lblChPass->setObjectName(QString::fromUtf8("lblChPass"));
        lblChPass->setStyleSheet(QString::fromUtf8(""));

        Password->addWidget(lblChPass);

        entrChPass = new QLineEdit(UserWin);
        entrChPass->setObjectName(QString::fromUtf8("entrChPass"));
        entrChPass->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        entrChPass->setReadOnly(true);

        Password->addWidget(entrChPass);


        SecondRow->addLayout(Password);

        verticalSpacer_5 = new QSpacerItem(20, 3, QSizePolicy::Minimum, QSizePolicy::Fixed);

        SecondRow->addItem(verticalSpacer_5);

        Role = new QHBoxLayout();
        Role->setSpacing(0);
        Role->setObjectName(QString::fromUtf8("Role"));
        lblChRole = new QLabel(UserWin);
        lblChRole->setObjectName(QString::fromUtf8("lblChRole"));
        lblChRole->setStyleSheet(QString::fromUtf8(""));

        Role->addWidget(lblChRole);

        entrChRole = new QLineEdit(UserWin);
        entrChRole->setObjectName(QString::fromUtf8("entrChRole"));
        entrChRole->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        entrChRole->setReadOnly(true);

        Role->addWidget(entrChRole);


        SecondRow->addLayout(Role);


        ChangeUserDataButtons->addLayout(SecondRow);


        Main->addLayout(ChangeUserDataButtons);

        verticalSpacer = new QSpacerItem(20, 9, QSizePolicy::Minimum, QSizePolicy::Fixed);

        Main->addItem(verticalSpacer);

        btnBack = new QPushButton(UserWin);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        Main->addWidget(btnBack);


        verticalLayout_2->addLayout(Main);


        retranslateUi(UserWin);

        QMetaObject::connectSlotsByName(UserWin);
    } // setupUi

    void retranslateUi(QDialog *UserWin)
    {
        UserWin->setWindowTitle(QCoreApplication::translate("UserWin", " User session - {Name}", nullptr));
        lblWelcome->setText(QCoreApplication::translate("UserWin", "Hello, {Name}!", nullptr));
        lblInfo->setText(QCoreApplication::translate("UserWin", "Your data", nullptr));
        lblChID->setText(QCoreApplication::translate("UserWin", "ID:         ", nullptr));
        lblChLastN->setText(QCoreApplication::translate("UserWin", "Last name:  ", nullptr));
        lblChFirstN->setText(QCoreApplication::translate("UserWin", "First name: ", nullptr));
        lblChLog->setText(QCoreApplication::translate("UserWin", "Login:    ", nullptr));
        lblChPass->setText(QCoreApplication::translate("UserWin", "Password: ", nullptr));
        lblChRole->setText(QCoreApplication::translate("UserWin", "Role:     ", nullptr));
        btnBack->setText(QCoreApplication::translate("UserWin", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class UserWin: public Ui_UserWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERWIN_H
