/********************************************************************************
** Form generated from reading UI file 'workerwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.0.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WORKERWINDOW_H
#define UI_WORKERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_WorkerWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *main;
    QLabel *lblWelcome;
    QPushButton *btnBack;

    void setupUi(QMainWindow *WorkerWindow)
    {
        if (WorkerWindow->objectName().isEmpty())
            WorkerWindow->setObjectName(QString::fromUtf8("WorkerWindow"));
        WorkerWindow->resize(300, 90);
        WorkerWindow->setMinimumSize(QSize(300, 90));
        WorkerWindow->setMaximumSize(QSize(300, 90));
        WorkerWindow->setStyleSheet(QString::fromUtf8("font: 11pt \"Consolas\";\n"
"background-color: rgb(170, 255, 0);"));
        centralwidget = new QWidget(WorkerWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        main = new QVBoxLayout();
        main->setObjectName(QString::fromUtf8("main"));
        lblWelcome = new QLabel(centralwidget);
        lblWelcome->setObjectName(QString::fromUtf8("lblWelcome"));
        lblWelcome->setAlignment(Qt::AlignCenter);

        main->addWidget(lblWelcome);

        btnBack = new QPushButton(centralwidget);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        main->addWidget(btnBack);


        verticalLayout_2->addLayout(main);

        WorkerWindow->setCentralWidget(centralwidget);

        retranslateUi(WorkerWindow);

        QMetaObject::connectSlotsByName(WorkerWindow);
    } // setupUi

    void retranslateUi(QMainWindow *WorkerWindow)
    {
        WorkerWindow->setWindowTitle(QCoreApplication::translate("WorkerWindow", " User", nullptr));
        lblWelcome->setText(QCoreApplication::translate("WorkerWindow", "Hello, {Name}!", nullptr));
        btnBack->setText(QCoreApplication::translate("WorkerWindow", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class WorkerWindow: public Ui_WorkerWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WORKERWINDOW_H
