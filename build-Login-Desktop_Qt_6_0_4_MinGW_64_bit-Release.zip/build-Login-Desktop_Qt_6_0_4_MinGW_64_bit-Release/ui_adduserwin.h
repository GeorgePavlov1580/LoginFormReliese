/********************************************************************************
** Form generated from reading UI file 'adduserwin.ui'
**
** Created by: Qt User Interface Compiler version 6.0.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDUSERWIN_H
#define UI_ADDUSERWIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_AddUserWin
{
public:
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *Main;
    QLabel *lblInfo;
    QFrame *line;
    QHBoxLayout *UserData;
    QVBoxLayout *Row1;
    QHBoxLayout *horizontalLayout;
    QLabel *lblID;
    QLineEdit *entr1;
    QHBoxLayout *horizontalLayout_2;
    QLabel *lblLastN;
    QLineEdit *entr2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *lblFirstN;
    QLineEdit *entr3;
    QVBoxLayout *Row2;
    QHBoxLayout *horizontalLayout_4;
    QLabel *lblLog;
    QLineEdit *entr4;
    QHBoxLayout *horizontalLayout_5;
    QLabel *lblPass;
    QLineEdit *entr5;
    QHBoxLayout *horizontalLayout_6;
    QLabel *lblRole;
    QRadioButton *rbtnAdmin;
    QRadioButton *rbtnUser;
    QPushButton *btnConfirm;
    QPushButton *btnBack;

    void setupUi(QDialog *AddUserWin)
    {
        if (AddUserWin->objectName().isEmpty())
            AddUserWin->setObjectName(QString::fromUtf8("AddUserWin"));
        AddUserWin->resize(400, 200);
        AddUserWin->setMinimumSize(QSize(400, 200));
        AddUserWin->setMaximumSize(QSize(1000, 600));
        AddUserWin->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 255, 0);\n"
"font: 11pt \"Consolas\";"));
        verticalLayout_4 = new QVBoxLayout(AddUserWin);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        Main = new QVBoxLayout();
        Main->setObjectName(QString::fromUtf8("Main"));
        lblInfo = new QLabel(AddUserWin);
        lblInfo->setObjectName(QString::fromUtf8("lblInfo"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(lblInfo->sizePolicy().hasHeightForWidth());
        lblInfo->setSizePolicy(sizePolicy);
        lblInfo->setStyleSheet(QString::fromUtf8("font: 16pt \"Consolas\";"));
        lblInfo->setAlignment(Qt::AlignCenter);

        Main->addWidget(lblInfo);

        line = new QFrame(AddUserWin);
        line->setObjectName(QString::fromUtf8("line"));
        line->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        Main->addWidget(line);

        UserData = new QHBoxLayout();
        UserData->setObjectName(QString::fromUtf8("UserData"));
        Row1 = new QVBoxLayout();
        Row1->setObjectName(QString::fromUtf8("Row1"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        lblID = new QLabel(AddUserWin);
        lblID->setObjectName(QString::fromUtf8("lblID"));

        horizontalLayout->addWidget(lblID);

        entr1 = new QLineEdit(AddUserWin);
        entr1->setObjectName(QString::fromUtf8("entr1"));
        entr1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout->addWidget(entr1);


        Row1->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        lblLastN = new QLabel(AddUserWin);
        lblLastN->setObjectName(QString::fromUtf8("lblLastN"));

        horizontalLayout_2->addWidget(lblLastN);

        entr2 = new QLineEdit(AddUserWin);
        entr2->setObjectName(QString::fromUtf8("entr2"));
        entr2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout_2->addWidget(entr2);


        Row1->addLayout(horizontalLayout_2);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        lblFirstN = new QLabel(AddUserWin);
        lblFirstN->setObjectName(QString::fromUtf8("lblFirstN"));

        horizontalLayout_3->addWidget(lblFirstN);

        entr3 = new QLineEdit(AddUserWin);
        entr3->setObjectName(QString::fromUtf8("entr3"));
        entr3->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout_3->addWidget(entr3);


        Row1->addLayout(horizontalLayout_3);


        UserData->addLayout(Row1);

        Row2 = new QVBoxLayout();
        Row2->setObjectName(QString::fromUtf8("Row2"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        lblLog = new QLabel(AddUserWin);
        lblLog->setObjectName(QString::fromUtf8("lblLog"));

        horizontalLayout_4->addWidget(lblLog);

        entr4 = new QLineEdit(AddUserWin);
        entr4->setObjectName(QString::fromUtf8("entr4"));
        entr4->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout_4->addWidget(entr4);


        Row2->addLayout(horizontalLayout_4);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        lblPass = new QLabel(AddUserWin);
        lblPass->setObjectName(QString::fromUtf8("lblPass"));

        horizontalLayout_5->addWidget(lblPass);

        entr5 = new QLineEdit(AddUserWin);
        entr5->setObjectName(QString::fromUtf8("entr5"));
        entr5->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        horizontalLayout_5->addWidget(entr5);


        Row2->addLayout(horizontalLayout_5);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        lblRole = new QLabel(AddUserWin);
        lblRole->setObjectName(QString::fromUtf8("lblRole"));

        horizontalLayout_6->addWidget(lblRole);

        rbtnAdmin = new QRadioButton(AddUserWin);
        rbtnAdmin->setObjectName(QString::fromUtf8("rbtnAdmin"));

        horizontalLayout_6->addWidget(rbtnAdmin);

        rbtnUser = new QRadioButton(AddUserWin);
        rbtnUser->setObjectName(QString::fromUtf8("rbtnUser"));

        horizontalLayout_6->addWidget(rbtnUser);


        Row2->addLayout(horizontalLayout_6);


        UserData->addLayout(Row2);


        Main->addLayout(UserData);

        btnConfirm = new QPushButton(AddUserWin);
        btnConfirm->setObjectName(QString::fromUtf8("btnConfirm"));
        btnConfirm->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        Main->addWidget(btnConfirm);

        btnBack = new QPushButton(AddUserWin);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        Main->addWidget(btnBack);


        verticalLayout_4->addLayout(Main);


        retranslateUi(AddUserWin);

        QMetaObject::connectSlotsByName(AddUserWin);
    } // setupUi

    void retranslateUi(QDialog *AddUserWin)
    {
        AddUserWin->setWindowTitle(QCoreApplication::translate("AddUserWin", " Add new user", nullptr));
        lblInfo->setText(QCoreApplication::translate("AddUserWin", "Add new user", nullptr));
        lblID->setText(QCoreApplication::translate("AddUserWin", "ID:        ", nullptr));
        lblLastN->setText(QCoreApplication::translate("AddUserWin", "Last name: ", nullptr));
        lblFirstN->setText(QCoreApplication::translate("AddUserWin", "First name:", nullptr));
        lblLog->setText(QCoreApplication::translate("AddUserWin", "Login:   ", nullptr));
        lblPass->setText(QCoreApplication::translate("AddUserWin", "Password:", nullptr));
        lblRole->setText(QCoreApplication::translate("AddUserWin", "Role:", nullptr));
        rbtnAdmin->setText(QCoreApplication::translate("AddUserWin", "Admin", nullptr));
        rbtnUser->setText(QCoreApplication::translate("AddUserWin", "User", nullptr));
        btnConfirm->setText(QCoreApplication::translate("AddUserWin", "Confirm", nullptr));
        btnBack->setText(QCoreApplication::translate("AddUserWin", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddUserWin: public Ui_AddUserWin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDUSERWIN_H
