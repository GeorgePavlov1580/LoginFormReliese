/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.0.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *main;
    QLabel *lblInfo;
    QFrame *hor_line;
    QHBoxLayout *login;
    QLabel *lblLogin;
    QLineEdit *entr1;
    QHBoxLayout *password;
    QLabel *lblPass;
    QLineEdit *entr2;
    QSpacerItem *verticalSpacer;
    QPushButton *btnConfirm;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(350, 170);
        MainWindow->setMinimumSize(QSize(350, 170));
        MainWindow->setMaximumSize(QSize(350, 170));
        QFont font;
        font.setPointSize(11);
        font.setBold(false);
        font.setItalic(false);
        MainWindow->setFont(font);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 255, 0);\n"
"font: 11pt \"Consolas\";"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        verticalLayout_2 = new QVBoxLayout(centralwidget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        main = new QVBoxLayout();
        main->setObjectName(QString::fromUtf8("main"));
        lblInfo = new QLabel(centralwidget);
        lblInfo->setObjectName(QString::fromUtf8("lblInfo"));
        lblInfo->setAlignment(Qt::AlignCenter);

        main->addWidget(lblInfo);

        hor_line = new QFrame(centralwidget);
        hor_line->setObjectName(QString::fromUtf8("hor_line"));
        hor_line->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        hor_line->setFrameShape(QFrame::HLine);
        hor_line->setFrameShadow(QFrame::Sunken);

        main->addWidget(hor_line);

        login = new QHBoxLayout();
        login->setObjectName(QString::fromUtf8("login"));
        lblLogin = new QLabel(centralwidget);
        lblLogin->setObjectName(QString::fromUtf8("lblLogin"));

        login->addWidget(lblLogin);

        entr1 = new QLineEdit(centralwidget);
        entr1->setObjectName(QString::fromUtf8("entr1"));
        entr1->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        login->addWidget(entr1);


        main->addLayout(login);

        password = new QHBoxLayout();
        password->setObjectName(QString::fromUtf8("password"));
        lblPass = new QLabel(centralwidget);
        lblPass->setObjectName(QString::fromUtf8("lblPass"));

        password->addWidget(lblPass);

        entr2 = new QLineEdit(centralwidget);
        entr2->setObjectName(QString::fromUtf8("entr2"));
        entr2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        password->addWidget(entr2);


        main->addLayout(password);

        verticalSpacer = new QSpacerItem(20, 10, QSizePolicy::Minimum, QSizePolicy::Fixed);

        main->addItem(verticalSpacer);

        btnConfirm = new QPushButton(centralwidget);
        btnConfirm->setObjectName(QString::fromUtf8("btnConfirm"));
        btnConfirm->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        main->addWidget(btnConfirm);


        verticalLayout_2->addLayout(main);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", " Registration form", nullptr));
        lblInfo->setText(QCoreApplication::translate("MainWindow", "Registartion form ", nullptr));
        lblLogin->setText(QCoreApplication::translate("MainWindow", "Login:    ", nullptr));
        lblPass->setText(QCoreApplication::translate("MainWindow", "Password: ", nullptr));
        btnConfirm->setText(QCoreApplication::translate("MainWindow", "Comfirm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
